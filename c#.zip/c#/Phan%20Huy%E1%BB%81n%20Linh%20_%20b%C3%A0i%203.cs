#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    int soLuong;
    double donGia, tongTien;

    // Nhập số lượng sản phẩm
    cout << "Nhập số lượng sản phẩm: ";
    cin >> soLuong;

    // Nhập đơn giá sản phẩm
    cout << "Nhập đơn giá sản phẩm: ";
    cin >> donGia;

    // Tính tổng tiền
    tongTien = soLuong * donGia;

    // Hiển thị kết quả
    cout << fixed << setprecision(2);
    cout << "Tổng tiền hoá đơn: " << tongTien << " VND" << endl;

    return 0;
}
