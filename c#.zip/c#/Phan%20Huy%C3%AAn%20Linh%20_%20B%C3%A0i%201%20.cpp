using Microsoft.AspNetcore.Mvc;
using System.Text.Encodings.wed;
namespace MvcMovie.Controller
{
    0 references
    public class BMIController : Controller
    {
        return View():

    }
    0 references
    public IActionResult Index(double height, double weight) 
    if (weight >0 && height>0{
        3 references
        double BMI = Weight /(Height*Height);
        O references
        string category = BMI<18.5? "Gầy":
                          BMI<24.9? "Bình thường":
                          BMI<29.9? "Béo phì ":
        ViewBag.BMI=BMI.tostring("0.00");
        ViewBag. Category = category;
    }
    else{

   
   


 using Microsoft.AspNetCore.Mvc;

namespace MvcMovie.Controllers
{
    public class BMIController : Controller
    {
        public IActionResult Index(double height, double weight)
        {
            if (weight > 0 && height > 0)
            {
                double BMI = weight / (height * height);
                string category = BMI < 18.5 ? "Gầy" :
                                  BMI < 24.9 ? "Bình thường" :
                                  BMI < 29.9 ? "Thừa cân" : "Béo phì";

                ViewBag.BMI = BMI.ToString("0.00");
                ViewBag.Category = category;
            }
            else
            {
                ViewBag.BMI = "Không hợp lệ";
                ViewBag.Category = "Vui lòng nhập chiều cao và cân nặng hợp lệ";
            }

            return View();
        }
    }
}
