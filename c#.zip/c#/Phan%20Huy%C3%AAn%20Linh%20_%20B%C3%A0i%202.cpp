#include <iostream>
using namespace std;

// Hàm tính điểm môn học
double tinhDiemMonHoc(double A, double B, double C) {
    return A * 0.6 + B * 0.3 + C * 0.1;
}

int main() {
    double A, B, C;
    
    // Nhập điểm thành phần
    cout << "Nhap diem A: ";
    cin >> A;
    cout << "Nhap diem B: ";
    cin >> B;
    cout << "Nhap diem C: ";
    cin >> C;
    
    // Kiểm tra giá trị hợp lệ (điểm từ 0 đến 10)
    if (A < 0 || A > 10 || B < 0 || B > 10 || C < 0 || C > 10) {
        cout << "Diem khong hop le! Vui long nhap lai." << endl;
        return 1;
    }
    
    // Tính và hiển thị điểm môn học
    double diemTong = tinhDiemMonHoc(A, B, C);
    cout << "Diem mon hoc: " << diemTong << endl;
    
    return 0;
}
